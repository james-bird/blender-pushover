# blender-pushover

A blender add-on to send pushover notifications when renders are complete.
